import os

currentDir = os.getcwd()
print('Current directory is:\n    ', currentDir)

#Open and then read the file
fileName = 'ypanel.kicad_pcb'

with open(currentDir+'\\'+fileName,"r") as pcbfile:
    line = pcbfile.readline()
    while line:
        check=False
        line = pcbfile.readline()
        if 'fp_arc' in line:
            # print(line.strip())
            line=line.strip().split(' ')
            width=float(line[line.index('(width')+1].strip('))'))
            x=(float(line[2]),float(line[5]))
            y=(float(line[3].strip(')')),float(line[6].strip(')')))
            if x[0]==x[1]:
                r=abs(y[0]-y[1])*0.99
                check=True
            elif y[0]==y[1]:
                r=abs(x[0]-x[1])*0.99
                check=True
            else:
                r=max((abs(x[0]-x[1]),abs(y[0]-y[1])))*0.99
                lyr  = line[line.index('(layer')+1].strip('))')
                # if lyr != '"Dwgs.User"':
                    # start= (float(line[2]),float(line[3].strip(')')))
                    # end  = (float(line[5]),float(line[6].strip(')')))
                    # print('ERROR (layer: {}) x: {}, y: {}'.format(lyr,x,y))
                    # print('\t{},{}'.format(start,end))
                    # print('\t{}'.format(line))
            if width/2 < r:
                print('GOOD\twidth/2: {} radius*0.99: {:.2f}'.format(width/2,r))
            else:
                print('BAD\twidth/2: {} radius*0.99: {:.2f}'.format(width/2,r))
                print('\t{}'.format(line))
            # print(x,y,width)
        elif 'gr_arc' in line:
            # print(line.strip())
            line=line.strip().split(' ')
            width=float(line[line.index('(width')+1].strip('))'))
            x=(float(line[2]),float(line[5]))
            y=(float(line[3].strip(')')),float(line[6].strip(')')))
            if x[0]==x[1]:
                r=abs(y[0]-y[1])*0.99
                check=True
            elif y[0]==y[1]:
                r=abs(x[0]-x[1])*0.99
                check=True
            else:
                r=max((abs(x[0]-x[1]),abs(y[0]-y[1])))*0.99
                lyr  = line[line.index('(layer')+1].strip('))')
                # if lyr != '"Dwgs.User"':
                    # start= (float(line[2]),float(line[3].strip(')')))
                    # end  = (float(line[5]),float(line[6].strip(')')))
                    # print('ERROR (layer: {}) x: {}, y: {}'.format(lyr,x,y))
                    # print('\t{},{}'.format(start,end))
                    # print('\t{}'.format(line))
            if width/2 < r:
                print('GOOD\twidth/2: {} radius*0.99: {:.2f}'.format(width/2,r))
            else:
                print('BAD\twidth/2: {} radius*0.99: {:.2f}'.format(width/2,r))
                print('\t{}'.format(line))

            # print(x,y,width)







